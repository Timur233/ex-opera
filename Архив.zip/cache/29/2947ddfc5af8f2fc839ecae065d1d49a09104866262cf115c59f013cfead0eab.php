<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/about_project.twig */
class __TwigTemplate_97e8b2ba4314e9f02ec8ff31d7082464291e357c038708a58261052434cc5f45 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- About -->
<section id=\"about\" class=\"about section-padding\">
    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-6 mb-30 animate-box\" data-animate-effect=\"fadeInUp\">
                <div class=\"section-subtitle\">Примиальный жилой комплекс</div>
                <div class=\"section-title\">Exclusive Opera</div>
                <p>
                    это новая классика: соединение прошлого и будущего, 
                    сохранение архитектурных и культурных традиций Южной столицы. 
                    Прежде всего это отражено в архитектурном исполнении жилого комплекса. 
                    Лицевой фасад дома идеально вписывается в архитектурный облик 
                    «золотого квадрата» города Алматы.
                </p>
                <!-- call -->
                <div class=\"reservations\">
                    <div class=\"icon\"><span class=\"flaticon-call\"></span></div>
                    <div class=\"text\">
                        <p>цент продаж</p> <a href=\"tel:+7 727 461 32 15\">+7 727 461 32 15</a>
                    </div>
                </div>
            </div>
            <div class=\"col col-md-5\">
                <img 
                    class=\"animate-box\"
                    src=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d8df1be0cafC9.jpg\"
                    data-animate-effect=\"fadeInUp\"
                >
                <img 
                    class=\"about-img--absolute animate-box\" 
                    src=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d8df1803cb4C9_2.jpg\"
                    data-animate-effect=\"fadeInUp\"
                >
            </div>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/about_project.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/about_project.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/about_project.twig");
    }
}
