<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/construct.twig */
class __TwigTemplate_798f734d991f030fb42906c24f073f30844968e51ab438ac3c0719e3f130a14b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Kostruct -->
<section class=\"facilties section-padding\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"section-subtitle\">Конструктив здания</div>
                <div class=\"section-title\">Конструктив здания и фундамента</div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-md-4\">
                <div class=\"single-facility animate-box\" data-animate-effect=\"fadeInUp\">
                    <span class=\"flaticon-menu\"></span>
                    <h5>Окна</h5>
                    <p>
                        Энергосберегающие, дерево-алюминиевые, двойной стеклопакет. 
                        Витраж алюминиевый теплой серии от «Shuco».
                    </p>
                    <div class=\"facility-shape\"> <span class=\"flaticon-menu\"></span> </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"single-facility animate-box\" data-animate-effect=\"fadeInUp\">
                    <span class=\"flaticon-menu\"></span>
                    <h5>Каркас и колонны</h5>
                    <p>
                        Монолитный, армированный железобетон для зданий и сооружений.
                    </p>
                    <div class=\"facility-shape\"> <span class=\"flaticon-menu\"></span> </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"single-facility animate-box\" data-animate-effect=\"fadeInUp\">
                    <span class=\"flaticon-menu\"></span>
                    <h5>Фундамент и несущий каркас</h5>
                    <p>
                        Монолитный железобетонный.
                    </p>
                    <div class=\"facility-shape\"> <span class=\"flaticon-menu\"></span> </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"single-facility animate-box\" data-animate-effect=\"fadeInUp\">
                    <span class=\"flaticon-menu\"></span>
                    <h5>Наружные стены</h5>
                    <p>
                        Монолитная железобетонная стена, утепленная экструзионными 
                        пенополистирольными плитами.
                    </p>
                    <div class=\"facility-shape\"> <span class=\"flaticon-menu\"></span> </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"single-facility animate-box\" data-animate-effect=\"fadeInUp\">
                    <span class=\"flaticon-menu\"></span>
                    <h5>Фасад</h5>
                    <p>
                        
                    </p>
                    <div class=\"facility-shape\"> <span class=\"flaticon-menu\"></span> </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"single-facility animate-box\" data-animate-effect=\"fadeInUp\">
                    <span class=\"flaticon-menu\"></span>
                    <h5>Стены</h5>
                    <p>We’ll pick up from airport while you comfy on your ride, mus nellentesque habitant.</p>
                    <div class=\"facility-shape\"> <span class=\"flaticon-menu\"></span> </div>
                </div>
            </div>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/construct.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/construct.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/construct.twig");
    }
}
