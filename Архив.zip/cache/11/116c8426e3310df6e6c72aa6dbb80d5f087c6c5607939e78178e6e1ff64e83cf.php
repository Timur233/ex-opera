<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/building_steps.twig */
class __TwigTemplate_2b6f8443fc31f72ce26fc32d5020b89425ca2604a8f1f7b76034a4c952e56877 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Building steps -->
<section class=\"news section-padding bg-black\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"section-subtitle\"><span>Строительство</span></div>
                <div class=\"section-title\"><span>Ход строительства</span></div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"owl-carousel owl-theme\">

                    <div class=\"item\">
                        <div 
                            class=\"position-re o-hidden building-steps__item\"
                            style=\"background-image: url(https://cms.abpx.kz/storage/styles/building_steps/6218b0b56666642ba7000343/e10f8c8838ebd23abc038c491f8b1785_1175x784_80_1645784937_fitToWidth_adb115059e28d960fa8badfac5516667.jpeg?cimgt=1645785269)\"    
                        >
                            <div class=\"date\">
                                <a href=\"post.html\"> <span>Март</span> <i>2022</i> </a>
                            </div>
                        </div>
                    </div>  
                    <div class=\"item\">
                        <div 
                            class=\"position-re o-hidden building-steps__item\"
                            style=\"background-image: url(https://cms.abpx.kz/storage/styles/building_steps/6218b0626337620c0d00034f/4a66b6776a4d9fe481d920f388cc0df0_1175x784_80_1645784999_fitToWidth_adb115059e28d960fa8badfac5516667.jpeg?cimgt=1645785186)\"    
                        >
                            <div class=\"date\">
                                <a href=\"post.html\"> <span>Февраль</span> <i>2022</i> </a>
                            </div>
                        </div>
                    </div>    
                    <div class=\"item\">
                        <div 
                            class=\"position-re o-hidden building-steps__item\"
                            style=\"background-image: url(https://cms.abpx.kz/storage/styles/building_steps/6218b02c3536648680000226/033c3a32caaf7a583ae45b7c3c9850ca_1175x784_80_1645784987_fitToWidth_adb115059e28d960fa8badfac5516667.jpeg?cimgt=1645785132)\"    
                        >
                            <div class=\"date\">
                                <a href=\"post.html\"> <span>Январь</span> <i>2022</i> </a>
                            </div>
                        </div>
                    </div> 
                    <div class=\"item\">
                        <div 
                            class=\"position-re o-hidden building-steps__item\"
                            style=\"background-image: url()\"    
                        >
                            <div class=\"date\">
                                <a href=\"post.html\"> <span>Декабрь</span> <i>2021</i> </a>
                            </div>
                        </div>
                    </div>                 
                    
                </div>
            </div>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/building_steps.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/building_steps.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/building_steps.twig");
    }
}
