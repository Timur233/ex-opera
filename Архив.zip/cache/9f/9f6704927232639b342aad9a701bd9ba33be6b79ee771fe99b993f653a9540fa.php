<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/slider.twig */
class __TwigTemplate_441041c46b336091de425aaedd8f935802b4e1214d81efc04da4d23404d1aadc extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Slider -->
<header id=\"main\" class=\"header slider-fade\">
    <div class=\"owl-carousel owl-theme\">
        <div class=\"text-center item bg-img\" data-overlay-dark=\"4\" data-background=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d8deeb5b24fC4_2.jpg\">
            <div class=\"v-middle caption\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-md-10 offset-md-1\">
                            <h4>Искусство идеальной жизни</h4>
                            <h1>Exclusive Opera</h1>
                            <div class=\"butn-light mt-30 mb-30\"> 
                                <a href=\"#appartaments\">
                                    <span>Квартиры</span>
                                </a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"text-center item bg-img\" data-overlay-dark=\"4\" data-background=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d8ded61d6faC2_2.jpg\">
            <div class=\"v-middle caption\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-md-10 offset-md-1\">
                            <h4>Искусство идеальной жизни</h4>
                            <h1>Exclusive Opera</h1>
                            <div class=\"butn-light mt-30 mb-30\"> 
                                <a href=\"#appartaments\">
                                    <span>Квартиры</span>
                                </a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"text-center item bg-img\" data-overlay-dark=\"4\" data-background=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d8defeb3791C6_2.jpg\">
            <div class=\"v-middle caption\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-md-10 offset-md-1\">
                            <h4>Искусство идеальной жизни</h4>
                            <h1>Exclusive Opera</h1>
                            <div class=\"butn-light mt-30 mb-30\"> 
                                <a href=\"#appartaments\">
                                    <span>Квартиры</span>
                                </a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class=\"container\">
        <div class=\"developer__logo\">
            <a href=\"https://exin.kz/\" target=\"_blank\">
                <img 
                    src=\"https://cms.abpx.kz/storage/uploads/2022/07/24/62ddd1ea62c6c61c9645a93a2blogo-bold-1.svg\" 
                    class=\"developer__img\"
                >
            </a>
        </div>
    </div>
</header>";
    }

    public function getTemplateName()
    {
        return "widgets/slider.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/slider.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/slider.twig");
    }
}
