<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/advantages.twig */
class __TwigTemplate_69ce5dd797f73b626913f6ac1cfcf18e0845c217eea9eed4df7649ad12f7956d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Advantages -->
<section id=\"advantages\" class=\"rooms1 section-padding bg-cream\" data-scroll-index=\"1\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"section-subtitle\">Преимущества</div>
                <div class=\"section-title\">Новая Муза старого центра</div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col-md-4\">
                <div class=\"item\">
                    <div class=\"position-re o-hidden\"> 
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d92624b7985C8_2-1.jpg\" alt=\"\"> 
                    </div>
                    <div class=\"con\">
                        <h5>Престижный район</h5>
                        <div class=\"line\"></div>
                        <div class=\"content\">
                            <p>
                                Удачное соседство с ключевыми достопримечательностями столицы 
                                позволяют резидентам вести интересную и насыщенную жизнь
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"item\">
                    <div class=\"position-re o-hidden\"> 
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/07/29/62e3bd676ec4b-.jpg\" alt=\"\"> 
                    </div>
                    <div class=\"con\">
                        <h5>Уникальный проект</h5>
                        <div class=\"line\"></div>
                        <div class=\"content\">
                            <p>
                                Премиальный жилой комплекс спроектирован с учетом самых 
                                высоких запросов покупателей.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"item\">
                    <div class=\"position-re o-hidden\"> 
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d926243f987C6_2-1.jpg\" alt=\"\"> 
                    </div>
                    <div class=\"con\">
                        <h5>Современная инфраструктура</h5>
                        <div class=\"line\"></div>
                        <div class=\"content\">
                            <p>
                                Изолированный от внешнего окружения внутренний двор, современный 
                                подземный паркинг и коммерческая зона на первом этаже
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6\">
                <div class=\"item\">
                    <div class=\"position-re o-hidden\"> 
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/07/24/62ddb7e7d72bd62678ae144a20-DUET-200200-1-1-1.jpg\" alt=\"\"> 
                    </div>
                    <div class=\"con\">
                        <h5>Подземный паркинг</h5>
                        <div class=\"line\"></div>
                        <div class=\"content\">
                            <p>
                                Всего для жителей предусмотрено 77 парковочных мест в подземном паркинге, 
                                в том числе и наземная гостевая парковка.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"col-md-6\">
                <div class=\"item\">
                    <div class=\"position-re o-hidden\"> 
                        <img src=\"https://cms.abpx.kz/storage/uploads/2022/07/24/62ddb7732074dC9-1.jpg\" alt=\"\"> 
                    </div>
                    <div class=\"con\">
                        <h5>Свободная планировка</h5>
                        <div class=\"line\"></div>
                        <div class=\"content\">
                            <p>
                                с возможностью создания индивидуального проекта
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/advantages.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/advantages.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/advantages.twig");
    }
}
