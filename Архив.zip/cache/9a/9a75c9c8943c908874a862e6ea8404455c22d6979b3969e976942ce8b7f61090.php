<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.twig */
class __TwigTemplate_ee8738a911f628187509bd57e39d8211fd560362fff3b744cb1930fb0bd35003 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<html lang=\"ru\">
  <head>
    <meta charset=\"UTF-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />

    <title>";
        // line 6
        echo twig_escape_filter($this->env, ($context["site_title"] ?? null), "html", null, true);
        echo "</title>
    <link rel=\"shortcut icon\" href=\"https://cms.abpx.kz/";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["site_favicon"] ?? null), "path", [], "any", false, false, false, 7), "html", null, true);
        echo "\" type=\"image/png\">
    <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Cormorant+SC:wght@300;400;500;600;700&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap\">
    <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/css/plugins.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/css/style.css\" />

    ";
        // line 13
        echo "  
  </head>
  <body>
    ";
        // line 17
        echo "
    <!-- Preloader -->
    <div class=\"preloader-bg\"></div>
    <div id=\"preloader\">
        <div id=\"preloader-status\">
            <div class=\"preloader-position loader\"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class=\"progress-wrap cursor-pointer\">
        <svg class=\"progress-circle svg-content\" width=\"100%\" height=\"100%\" viewBox=\"-1 -1 102 102\">
            <path d=\"M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98\" />
        </svg>
    </div>

    ";
        // line 32
        echo twig_include($this->env, $context, "widgets/_header.twig");
        echo "

    ";
        // line 34
        echo twig_include($this->env, $context, "widgets/slider.twig");
        echo "

    ";
        // line 36
        echo twig_include($this->env, $context, "widgets/about_project.twig");
        echo "

    ";
        // line 38
        echo twig_include($this->env, $context, "widgets/advantages.twig");
        echo "

    ";
        // line 40
        echo twig_include($this->env, $context, "widgets/appartaments.twig");
        echo "

    ";
        // line 42
        echo twig_include($this->env, $context, "widgets/construct.twig");
        echo "

    ";
        // line 44
        echo twig_include($this->env, $context, "widgets/building_steps.twig");
        echo "

    ";
        // line 46
        echo twig_include($this->env, $context, "widgets/about_developer.twig");
        echo "

    ";
        // line 48
        echo twig_include($this->env, $context, "widgets/contacts.twig");
        echo "

    ";
        // line 50
        echo twig_include($this->env, $context, "widgets/footer.twig");
        echo "

    ";
        // line 52
        echo twig_include($this->env, $context, "widgets/modal.twig");
        echo "

  </body>

  <script>

    var translater = new Object({
      count_rooms: \"";
        // line 59
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["count_rooms"] ?? null) : null), "html", null, true);
        echo "\",
      floor: \"";
        // line 60
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["floor"] ?? null) : null), "html", null, true);
        echo "\",
      square: \"";
        // line 61
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["square"] ?? null) : null), "html", null, true);
        echo "\",
      download_plan: \"";
        // line 62
        echo twig_escape_filter($this->env, (($__internal_compile_3 = ($context["translate"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["download_plan"] ?? null) : null), "html", null, true);
        echo "\",
      leave_a_request: \"";
        // line 63
        echo twig_escape_filter($this->env, (($__internal_compile_4 = ($context["translate"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["leave_a_request"] ?? null) : null), "html", null, true);
        echo "\",
      no_valid_number: \"";
        // line 64
        echo twig_escape_filter($this->env, (($__internal_compile_5 = ($context["translate"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["no_valid_number"] ?? null) : null), "html", null, true);
        echo "\",
      multiplier: \"";
        // line 65
        echo twig_escape_filter($this->env, (($__internal_compile_6 = ($context["translate"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6["multiplier"] ?? null) : null), "html", null, true);
        echo "\",
      multiplierX1: \"";
        // line 66
        echo twig_escape_filter($this->env, (($__internal_compile_7 = ($context["translate"] ?? null)) && is_array($__internal_compile_7) || $__internal_compile_7 instanceof ArrayAccess ? ($__internal_compile_7["multiplierX1"] ?? null) : null), "html", null, true);
        echo "\"
    })

    var frontend = (function frontendModule() {

      function authorMarker() {
        console.log(\"%cExclusive Qurylys with Iskandarov Timur\", \"color:#fff; background-color:#7eb621; padding: 8px 15px; font-size: 14px; border-radius: 4px; text-align:center\")
      }

      function paralaxSlider(offset) {
        if (offset <= 650) {
          const paralaxLayers = document.querySelectorAll('.parallax__layer');

          paralaxLayers.forEach((layer) => {
            const speed = layer.getAttribute('data-speed');
            const duration = layer.getAttribute('data-duration');
            const transform = offset/duration;

            layer.style.transition = speed + \"s all\";
            layer.style.transform = layer.style.transform.split(' ')[0] + \" translateY(\" + transform + \"px)\";
          });
        }
      }

      function creiateMap() {
        var map = document.querySelector('.dragscroll>img.map-image');
        var container = document.querySelector('.dragscroll');

        if (map) {
            showCenterMap()

            function showCenterMap() {
                map.style.position = 'absolute';
                let left = ((map.offsetWidth - container.offsetWidth) / 2) * -1
                let top = ((map.offsetHeight - container.offsetHeight) / 2) * -1
                map.style.left = left + 'px'
                map.style.top = top + 'px'
            }

            map.onmousedown = function(e) {

            var coords = getCoords(map);
            var shiftX = e.pageX - coords.left;
            var shiftY = e.pageY - coords.top;

            moveAt(e);

            function moveAt(e) {
                map.style.left = getLmits(e).left + 'px';
                map.style.top = getLmits(e).top + 'px';
            }

            function getLmits(e) {

                let left = e.pageX - container.offsetLeft - shiftX
                let top = e.pageY - container.offsetTop - shiftY

                if (left > 0) {
                left = 0
                }

                if (left < ((map.offsetWidth - container.offsetWidth) * -1))     {
                left = ((map.offsetWidth - container.offsetWidth) * -1)
                }

                if (top > 0) {
                top = 0
                }

                if (top < ((map.offsetHeight - container.offsetHeight) * -1))     {
                top = ((map.offsetHeight - container.offsetHeight) * -1)
                }

                return {
                left: left,
                top: top
                }

            }

            document.onmousemove = function(e) {
                moveAt(e);
            };

            map.onmouseup = function() {
                document.onmousemove = null;
                map.onmouseup = null;
            };

            }

            map.ondragstart = function() {
            return false;
            };

            function getCoords(elem) {   // кроме IE8-
            var box = elem.getBoundingClientRect();
            return {
                top: box.top + pageYOffset,
                left: box.left + pageXOffset
            };
            }
        }
      }

      function yandexMap() {
        let center = [43.24641323957241,76.80753750657647];
            if (window.outerWidth < 720) {
                center = [43.24641323957241,76.80753750657647];
            }

            searchMap = new ymaps.Map('interective-map', {
                center: center,
                zoom: 15,
                controls: ['zoomControl'],
            });

            cildrenCollection = new ymaps.GeoObjectCollection(null)
            medicalShopCollection = new ymaps.GeoObjectCollection(null)
            medicalCollection = new ymaps.GeoObjectCollection(null)
            schoolCollection = new ymaps.GeoObjectCollection(null)
            sportCollection = new ymaps.GeoObjectCollection(null)
            shopCollection = new ymaps.GeoObjectCollection(null)

            let cildren = [[43.241623, 76.804920], [43.244982, 76.813536], [43.244691, 76.818094], [43.246475, 76.816390], [43.247704, 76.815030], [43.245693, 76.822420], [43.239383, 76.816692], [43.239705, 76.819423], [43.238654, 76.819620], [43.238332, 76.821066]]
            let medicalShop = [[43.241391, 76.812323],[43.241548, 76.813604], [43.245348, 76.815990], [43.242534, 76.818691], [43.242099, 76.819535], [43.241629, 76.817671], [43.243337, 76.815545], [43.242654, 76.815094], [43.242855, 76.813658]]
            let medical = [[43.233883, 76.787446], [43.244020, 76.819027], [43.241816, 76.813340], [43.242649, 76.814736], [43.242095, 76.811981], [43.229371, 76.802200], [43.246503, 76.846616], [43.232789, 76.800194]]
            let school = [[43.244226, 76.816779], [43.237635, 76.823281], [43.247580, 76.800784], [43.248077, 76.824543]]
            let sport = [[43.243157, 76.817861], [43.241708, 76.825342], [43.237486, 76.826608]]
            let shop = [[43.241629, 76.817662],[43.241340, 76.812321],[43.242083, 76.812304],[43.242338, 76.813797],[43.242025, 76.813228], [43.242222, 76.816105], [43.242745, 76.816184], [43.242786, 76.813692]]
            for (var i = 0, l = cildren.length; i < l; i++) {
                cildrenCollection.add(new ymaps.Placemark(cildren[i], {hintContent: 'Детский сад',balloonContent: ''},{iconLayout: 'default#image',
                    iconImageHref: 'https://shaharcity.kz/assets/img/map/childrens.svg',iconImageSize: [30, 40.9],iconImageOffset: [-15, -40.9],}));
            }
            for (var i = 0, l = medicalShop.length; i < l; i++) {
                medicalShopCollection.add(new ymaps.Placemark(medicalShop[i], {hintContent: 'Аптека',balloonContent: ''},{iconLayout: 'default#image',
                    iconImageHref: 'https://shaharcity.kz/assets/img/map/medical_shop.svg',iconImageSize: [30, 40.9],iconImageOffset: [-15, -40.9],}));
            }
            for (var i = 0, l = medical.length; i < l; i++) {
                medicalCollection.add(new ymaps.Placemark(medical[i], {hintContent: 'Поликлиника',balloonContent: ''},{iconLayout: 'default#image',
                    iconImageHref: 'https://shaharcity.kz/assets/img/map/medical_red.svg',iconImageSize: [30, 40.9],iconImageOffset: [-15, -40.9],}));
            }
            for (var i = 0, l = school.length; i < l; i++) {
                schoolCollection.add(new ymaps.Placemark(school[i], {hintContent: 'Школа',balloonContent: ''},{iconLayout: 'default#image',
                    iconImageHref: 'https://shaharcity.kz/assets/img/map/school.svg',iconImageSize: [30, 40.9],iconImageOffset: [-15, -40.9],}));
            }
            for (var i = 0, l = sport.length; i < l; i++) {
                sportCollection.add(new ymaps.Placemark(sport[i], {hintContent: 'Фитнес-центр',balloonContent: ''},{iconLayout: 'default#image',
                    iconImageHref: 'https://shaharcity.kz/assets/img/map/sport.svg',iconImageSize: [30, 40.9],iconImageOffset: [-15, -40.9],}));
            }
            for (var i = 0, l = shop.length; i < l; i++) {
                shopCollection.add(new ymaps.Placemark(shop[i], {hintContent: ' Супермаркет',balloonContent: ''},{iconLayout: 'default#image',
                    iconImageHref: 'https://shaharcity.kz/assets/img/map/shop.svg',iconImageSize: [30, 40.9],iconImageOffset: [-15, -40.9],}));
            }

            (marker = new ymaps.Placemark([43.24641323957241,76.80753750657647],
                {},
                {
                    iconLayout: 'default#image',
                    iconImageHref: 'https://cms.abpx.kz/storage/uploads/2022/02/10/6204ebf9b7751marker1.svg',
                    iconImageSize: [144, 82],
                    iconImageOffset: [-77, -82],
                }
            ));

            (marker_two = new ymaps.Placemark([43.266836074524655,76.81988049999998],
                {
                  balloonContentHeader: \"Отдел продаж\",
                  hintContent: \"Отдел продаж\"
                },
                {
                    iconLayout: 'default#image',
                    iconImageHref: 'https://cms.abpx.kz/storage/uploads/2022/02/10/6204ebf9b7751marker1.svg',
                    iconImageSize: [144, 82],
                    iconImageOffset: [-77, -82],
                }
            ));
            searchMap.geoObjects.add(cildrenCollection);
            searchMap.geoObjects.add(medicalShopCollection);
            searchMap.geoObjects.add(medicalCollection);
            searchMap.geoObjects.add(schoolCollection);
            searchMap.geoObjects.add(sportCollection);
            searchMap.geoObjects.add(shopCollection);
            searchMap.geoObjects.add(marker);
            searchMap.geoObjects.add(marker_two);
            searchMap.behaviors.disable('scrollZoom');
      }

      function closePreloader() {

        setTimeout( () => {
          fade(document.getElementById('preloader'))
        }
        ,0)

      }

      function creiateUserNotification() {
        if (localStorage.getItem('notificationCheck') != 'yes') {
          var notificationModalEl = document.getElementById('notificationModal')
          if (notificationModalEl) {
            let notificationModal = new bootstrap.Modal(notificationModalEl, {
              keyboard: false
            })
            notificationModal.show()

            let closeNotification = document.querySelector('#notificationModal .btn-close')
            closeNotification.addEventListener('click', () => { localStorage.setItem('notificationCheck', 'yes') })
            notificationModalEl.addEventListener('click', () => { localStorage.setItem('notificationCheck', 'yes') })
          }
        }
      }

      function fade(element) {
        var op = 1;  // initial opacity
        var timer = setInterval(function () {
          if (op <= 0.1){
            clearInterval(timer);
            element.style.display = 'none';
          } else if (op >= 1) {
            
          }
          element.style.opacity = op;
          element.style.filter = 'alpha(opacity=' + op * 100 + \")\";
          op -= op * 0.16;
        }, 0.1);
      }

      function sideBarToggle(condition) {
        const toggleBtn = document.querySelector('.menu-toggle');
        const sideBar = document.querySelector('.sidebar');
        const header = document.querySelector('.main-header');

        toggleBtn.classList.remove('menu-toggle--open');
        sideBar.classList.remove('sidebar--open');

        if (window.pageYOffset < 300)
        header.classList.remove ('main-header--sticky');
      }

      function sideBarToggleBtnEvent () {
        const toggleBtn = document.querySelector('.menu-toggle');
        const sideBar = document.querySelector('.sidebar');
        const header = document.querySelector('.main-header');

        toggleBtn.addEventListener('click', () => {
            toggleBtn.classList.toggle('menu-toggle--open');
            sideBar.classList.toggle('sidebar--open');

            if (window.pageYOffset < 300)
            header.classList.toggle('main-header--sticky');
        });
      }

      function buildingStepsCarousel() {
        let steps = new Swiper('.building-steps__swiper', {
          effect: null,
          loop: false,
          slidesPerView: 1.8,
          initialSlide: 0,
          keyboardControl: true,
          mousewheelControl: true,
          lazyLoading: true,
          centeredSlides: false,
          preventClicks: true,
          preventClicksPropagation: false,
          lazyLoadingInPrevNext: true,
          spaceBetween: 24,
          navigation: {
              nextEl: \".building-steps__controll.building-steps__controll--right\",
              prevEl: \".building-steps__controll.building-steps__controll--left\",
          },
          on: {
            afterInit: function() {
              const firstSlide = this.slides[0];
              const arrowLeft = this.navigation.\$prevEl[0];
              const arrowRight = this.navigation.\$nextEl[0];

              arrowRight.style.left = firstSlide.offsetWidth;
            },
          }
        });

        buildingStepsAutoHeight();

      }

      function buildingStepsAutoHeight() {

        //Set autoHeight
        let steps_items = document.querySelectorAll('.building-steps__swiper .swiper-slide');

        steps_items.forEach(function (step) {
          let height = (step.offsetWidth / 10) * 10;
          step.style.height = height;
        })

      }

      function advantagesCarousel() {
        const toggleEl = (el) => {
          if (!el) return;
          const elContent = el.querySelector('.advantages__body');
          const isActive = el.classList.contains('advantages__slide--active');

          el.style.width = (!isActive ? el.offsetWidth * 2 : el.offsetWidth / 2) + 'px';
          setTimeout(() => {
            elContent.style.height = !isActive ? elContent.scrollHeight : 0;
          }, 280)
          
          el.classList.toggle('advantages__slide--active');
        };
        let lastIndex = null;
        
        new Swiper('.advantages__swiper', {
          loop: true,
          slidesPerView: 4,
          spaceBetween: 1,
          navigation: {
            nextEl: \".swiper-button-next\",
            prevEl: \".swiper-button-prev\",
          },
          on: {
            click: function (e) {
              toggleEl(this.slides[lastIndex]);

              if (lastIndex !== e.clickedIndex) {
                toggleEl(this.slides[lastIndex = e.clickedIndex]);

                return;
              }

              lastIndex = null;   
            }
          }
        });
      }

      function comfortCarousel() {

        let body = null;
        let label = null;
        const showContent = (swiper) => {
          if (body && label) {
            body.style.display = 'none';
            label.style.display = 'none';
          }

          const currentSlide = swiper.slides[swiper.activeIndex];
          
          body = currentSlide.querySelector('.comfort__body');
          body.style.display = 'block';

          label = currentSlide.querySelector('.author-label');
          label.style.display = 'block';
        };

        let comfort = new Swiper('.comfort__swiper', {
          effect: false,
          loop: true,
          loopFillGroupWithBlank: true,
          centeredSlides: true,
          slidesPerView: 1.6,
          initialSlide: 0,
          keyboardControl: true,
          mousewheelControl: true,
          lazyLoading: false,
          preventClicks: true,
          preventClicksPropagation: true,
          lazyLoadingInPrevNext: true,
          spaceBetween: 24,
          navigation: {
            nextEl: \".swiper-button-next\",
            prevEl: \".swiper-button-prev\",
          },
          pagination: {
            el: \".swiper-pagination\",
          },
          on: {
            afterInit: function() {
              showContent(this);
            },
            slideChange: function () {
              showContent(this);
            }
          }
        });

      }

      function galleryCarousel() {

        var galery = new Swiper('.park-almaly__swiper', {
          loop: false,
          slidesPerView: 1,
          initialSlide: 0,
          keyboardControl: false,
          mousewheelControl: false,
          autoHeight: true,
          spaceBetween: 0,
          navigation: {
            nextEl: \".park-almaly__controll--right\",
            prevEl: \".park-almaly__controll--left\",
          },
          on: {
            init: function() {
              this.slides.forEach(function (slide) {
                let height = (slide.offsetWidth / 10) * 12;
                slide.style.height = height;
              })
            },
          }
        })

      }

      function mainSliderCarousel() {
        let title, content, button = null;
        const showContent = (swiper) => {
          if (title) {
            title.style.display = 'none';
            content.style.display = 'none';
            button.style.display = 'none';
          }

          const currentSlide = swiper.slides[swiper.activeIndex];
          
          title = currentSlide.querySelector('.slider-content__title');
          title.style.setProperty('--animate-duration', '1s');
          title.style.display = 'block';

          content = currentSlide.querySelector('.slider-content__body');
          content.style.setProperty('--animate-duration', '1.2s');
          content.style.display = 'block';

          button = currentSlide.querySelector('.slider-content__button');
          button.style.setProperty('--animate-duration', '1.5s');
          button.style.display = 'inline-block';
        };

        var galery = new Swiper('.main-slider__swiper', {
          // direction: \"vertical\",
          loop: true,
          slidesPerView: \"auto\",
          initialSlide: 0,
          keyboardControl: true,
          mousewheelControl: true,
          autoHeight: true,
          spaceBetween: 0,
          pagination: {
            el: '.main-slider__pagination',
            clickable: true,
            renderBullet: function (index, className) {
                return '<span class=\"' + className + '\">' + (index + 1) + '</span>';
            }
          },
          on: {
            afterInit: function() {
              showContent(this);
            },
            slideChange: function () {
              showContent(this);
            }
          }
        })

      }

      function creiateLightbox(data) {

        var lightbox = new FsLightbox()
        data = data.split(',')
        lightbox.props.sources = data
        lightbox.props.onInit
        lightbox.open()

      }

      function inputGroupFocus() {
        const groups = document.querySelectorAll('.callback-h__group:not(.callback-h__group--processed)');
  
        Array.from(groups).forEach(group => {
    
          const input = group.querySelector('input');
          const label = group.querySelector('label');

          if (input) {
            input.addEventListener('focus', function () {
              label.classList.add('callback-h__label--focus');
            });

            input.addEventListener('blur', function () {
              if (this.value === '') label.classList.remove('callback-h__label--focus');
            });
          }

          group.classList.add('callback-h__group--processed');
        });
      }

      function phoneValidator(){

        var phoneInputs = document.querySelectorAll('input[name=\"phone\"]')
        phoneInputs.forEach((el) => {
          el.addEventListener('input', function (e) {
            clearMessages()
            let numberCodes = ['710','711','712','713','714','715','716','717','718','721','722','723','724','725','726','727','728','729','736','700','701','702','703','704','705','706','707','708','709','747','750','751','760','761','762','763','764','771','775','776','777','778']
            let x = e.target.value.replace(/\\D/g, '').match(/(^\\d{0,1})(\\d{0,3})(\\d{0,3})(\\d{0,2})(\\d{0,2})/);

            e.target.value = !x[3] ? \"+\" + x[1] + x[2] : \"+\" + x[1] + ' (' + x[2] + ') ' + x[3] + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');

            let errMess = document.createElement('span')
            errMess.classList.add('input-err')
            errMess.textContent = translater.no_valid_number

            //console.log(numberCodes.indexOf(x[2]))
            if (x[3] && ((x[1] != '7') || (numberCodes.indexOf(x[2]) == -1))) {
              el.parentNode.appendChild(errMess)
            } else {
              clearMessages()
            }

          });
        })

      }

      function validatePhoneNumber(number) {
        if (number.match(/^\\+\\d{1} \\(\\d{3}\\) \\d{3}\\-\\d{2}\\-\\d{2}\$/)) {
          return true
        } else {
          return false
        }
      }

      function clearMessages() {
        let messAll = document.querySelectorAll('.input-err')
        messAll.forEach((el) => {
          el.remove()
        })
      }

      function formValidator(element) {
        let errors = false;
        let form = element;
        let inputs = form.querySelectorAll('input, textarea');
        let userName = form.querySelector('[name=\"name\"]');
        let formQuery = new Object();

        let preloader = document.createElement('div');
        preloader.classList.add('form-preloader');
        form.appendChild(preloader);

        if (userName.value == '') {
          let label = userName.parentNode.querySelector('.callback-h__label');

          if (label) label.classList.add('callback-h__label--focus');
          userName.value = 'Не указано';
        }

        inputs.forEach(function (el) {

          if (el.hasAttribute(\"required\") && el.value != \"\" || !el.hasAttribute(\"required\") && el.value != \"\") {
            let id = el.id;
            let name = el.getAttribute('fieldname');
            let data = el.value;
            formQuery[''+id] = {name, data};
          } else {
            if (el.hasAttribute(\"required\")) {
              el.setAttribute('style', 'border-color: red;');
              errors = true;
            }
          }

          if (el.name == 'phone') {
            if (!validatePhoneNumber(el.value)) {
              clearMessages();
              let errMess = document.createElement('span');
              errMess.classList.add('input-err');
              errMess.textContent = translater.no_valid_number;
              el.parentNode.appendChild(errMess);
              errors = true;
            } else {
              clearMessages();
            }
          }

        })

        if (!errors) {
          let user_data = collect_user_data();
          formQuery = Object.assign(formQuery, user_data);
          formSendData(formQuery, form);
        } else {
          preloader.remove();
        }

      }

      function collect_user_data(){

        const url = new URL(document.location.href)
        let user_data = new Object()

        //UTM DATA
        if (url.searchParams.get('utm_source')) {
          let name = 'utm_source'
          let data = url.searchParams.get('utm_source')
          user_data['utm_source'] = {name: name, data: data}
        }

        if (url.searchParams.get('utm_medium')) {
          let name = 'utm_medium'
          let data = url.searchParams.get('utm_medium')
          user_data['utm_medium'] = {name: name, data: data}
        }

        if (url.searchParams.get('utm_campaign')) {
          let name = 'utm_campaign'
          let data = url.searchParams.get('utm_campaign')
          user_data['utm_campaign'] = {name: name, data: data}
        }

        if (url.searchParams.get('utm_term')) {
          let name = 'utm_term'
          let data = url.searchParams.get('utm_term')
          user_data['utm_term'] = {name: name, data: data}
        }

        if (url.searchParams.get('utm_content')) {
          let name = 'utm_content'
          let data = url.searchParams.get('utm_content')
          user_data['utm_content'] = {name: name, data: data}
        }

        //UserAgent
        if (window.navigator.userAgent) {
          let name = 'userAgent'
          let data = window.navigator.userAgent
          user_data['userAgent'] = {name: name, data: data}
        }

        //Cookie
        if (get_cookie('_ga')) {
          let name = '_ga'
          let data = get_cookie('_ga').split('.')
          data = data[data.length - 2] + '.' + data[data.length - 1]
          user_data['_ga'] = {name: name, data: data}
        }

        //GetCookie Function
        function get_cookie ( cookie_name )
        {
          var results = document.cookie.match ( '(^|;) ?' + cookie_name + '=([^;]*)(;|\$)' );

          if ( results )
            return ( unescape ( results[2] ) );
          else
            return null;
        }

        return user_data

      }

      async function formSendData(formQuery, form) {
        let response = await fetch('/form/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json;charset=utf-8'
          },
          body: JSON.stringify(formQuery)
        });
        debugger;
        document.location.href = \"/thanks\";

        form.innerHTML = await response.text()

      }

      const locationFilter = (function () {

        const filterParams = {
          rooms: null,
          floor: null,
          square: null
        };
        
        const startNewSwiper = () => {
          let flatsCarousel = \$('.locations-result__carousel');
          
          flatsCarousel.owlCarousel({
              loop:       false,
              margin:     0,
              nav:        true,
              navText:    [
                '<i class=\"ti-angle-left\" aria-hidden=\"true\"></i>',
                '<i class=\"ti-angle-right\" aria-hidden=\"true\"></i>'
              ],
              responsive: {
                  0: {
                      items: 1
                  },
                  600: {
                      items: 1
                  },
                  1000: {
                      items: 1
                  }
              }
          });
        }

        const renderOffers = (locations) => {
          const parent = document.querySelector('.locations__result');
          let html = '';

          html += `<div class=\"locations-result__carousel owl-carousel\">`;

          locations.forEach((location, index) => {
            html += `
              <div class=\"locations-result__item\">
                <div class=\"row location\">
                  <div class=\"col-md-4 location__info\">
                    <div class=\"locations-result__data\">
                      <h4 class=\"location__title\">\${location.rooms} комнатная</h4>
                      <p class=\"location__square\">Площадь: <b>\${location.square} м<sup>2</sup></b></p>
                    </div>
                    <div class=\"location__btn-group\">
                      <a class=\"location__download\" href=\"https://cms.abpx.kz\${location.plan.path}\" onclick=\"frontend.popup(this); return false\">
                        Скачать планировку
                      </a>
                      <button class=\"btn location__btn location__btn--id-\${index}\" onclick=\"frontend.modal(); return false;\">
                        Оставить заявку
                      </button>
                    </div>
                  </div>
                  <div class=\"col-md-8 location__img-block d-flex justify-content-center align-items-center\">
                    <a href=\"https://cms.abpx.kz\${location.plan.path}\" onclick=\"frontend.popup(this); return false\" >
                      <img class=\"location__img\" src=\"https://cms.abpx.kz\${location.plan.path}\" />
                    </a>
                  </div>
                </div>
              </div>`
            ;
          });

          html += `</div>`;

          parent.innerHTML = html;

          startNewSwiper();
          
        };

        const renderButtons = (locations) => {
          const locationsFilter = document.querySelector('.locations-filter');
          const rooms =  new Set(); 
          let floors =  new Set(); 
          const squares =  new Set(); 

          locations.map((location) => {
            rooms.add(location.rooms);
            floors = new Set(location.floors.concat(...floors));
            squares.add(location.square);
          });
          
          locationsFilter.innerHTML = '';

          (function () {
            const label = document.createElement('span');
            const btnsGroup = document.createElement('div');
            let roomsButtons = null;
            
            label.classList = 'locations-filter__label';
            label.textContent = 'Количество комнат:';
            locationsFilter.appendChild(label);
            
            btnsGroup.classList = 'locations-filter__group filter-group';

            roomsButtons = [...rooms].sort((a,b) => {
              return a - b;
            });
            roomsButtons.forEach((room) => {
              const btn = document.createElement('button'); 

              btn.classList = 'btn filter-group__btn filter-group__btn--room';

              if (filterParams.rooms == room) {
                btn.classList.add('active')
              }

              btn.textContent = room + ' Комнатные';
              btn.setAttribute('data-filter', room);

              btn.addEventListener('click', (e) => {

                if (btn.classList.contains('active')) {
                  filterParams.rooms = null;
                } else {
                  filterParams.rooms = room;
                }

                filterParams.floor = null;
                filterParams.square = null;
                
                updateFilter();
              });

              btnsGroup.appendChild(btn);
            });

            locationsFilter.appendChild(btnsGroup);
          })();
          
          (function () {
            const label = document.createElement('span');
            const btnsGroup = document.createElement('div');
            let floorsButtons = null;
            
            label.classList = 'locations-filter__label';
            label.textContent = 'Этаж:';
            locationsFilter.appendChild(label);
            
            btnsGroup.classList = 'locations-filter__group filter-group';

            floorsButtons = [...floors].sort((a,b) => {
              return a - b;
            });
            floorsButtons.forEach((floor) => {
              const btn = document.createElement('button'); 

              btn.classList = 'btn filter-group__btn filter-group__btn--floors';

              if (filterParams.floor == floor) {
                btn.classList.add('active')
              }

              btn.textContent = floor;
              btn.setAttribute('data-filter', floor);

              btn.addEventListener('click', () => {

                if (btn.classList.contains('active')) {
                  filterParams.floor = null;
                } else {
                  filterParams.floor = floor;
                }

                filterParams.square = null;

                updateFilter();

              });

              btnsGroup.appendChild(btn);
            });

            locationsFilter.appendChild(btnsGroup);
          })();
          
          (function () {
            const label = document.createElement('span');
            const btnsGroup = document.createElement('div');
            let squaresButtons = null;
            
            label.classList = 'locations-filter__label';
            label.textContent = 'Площадь:';
            locationsFilter.appendChild(label);
            
            btnsGroup.classList = 'locations-filter__group filter-group';

            squaresButtons = [...squares].sort((a,b) => {
              return a - b;
            });
            squaresButtons.forEach((square) => {
              const btn = document.createElement('button'); 

              btn.classList = 'btn filter-group__btn filter-group__btn--square';

              if (filterParams.square == square) {
                btn.classList.add('active')
              }
              
              btn.innerHTML = square + ' м <sup>2</sup>';
              btn.setAttribute('data-filter', square);

              btn.addEventListener('click', () => {
                if (btn.classList.contains('active')) {
                  filterParams.square = null;
                } else {
                  filterParams.square = square;
                }

                updateFilter();
              });

              btnsGroup.appendChild(btn);
            });

            locationsFilter.appendChild(btnsGroup);
          })();

        };

        const fetchData = (rooms = null, floor = null, square = null) => {
          const url = new URL('filter', document.location.href);
          const params = {}
          
          !rooms || (params.rooms = rooms);
          !floor || (params.floor = floor);
          !square || (params.square = square);

          // !rooms || url.searchParams.set('rooms', rooms);
          // !floor || url.searchParams.set('floor', floor);
          // !square || url.searchParams.set('square', square);

          fetch(url.href, {
            method: 'POST', 
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
          })
            .then(res => res.json())
            .then(res => {
              //Checked errors
              renderButtons(res.entries);
              renderOffers(res.entries);
            });
        };

        const updateFilter = () => {
          fetchData(
            filterParams.rooms,
            filterParams.floor,
            filterParams.square
          );
        };

        fetchData();
      })()

      var newFilter = (function creiateFilter() {

        function getFloors(offers, filters) {
          let floorsBtnHtml = \"\"
          let floorsNumberArray = []
          for (var offer in offers) {
            for (var floor in offers[offer].floors) {
              if (!floorsNumberArray.includes(offers[offer].floors[floor])) {
                floorsNumberArray.push(offers[offer].floors[floor])
                floorsBtnHtml = floorsBtnHtml + '<a class=\"floor-buttons__item sections\" data-filter=\"' + offers[offer].floors[floor] + '\" href=\"#\" onclick=\"frontend.filterClick(\\'#floorButtons\\', this.getAttribute(\\'data-filter\\')); frontend.filterCreiate(offersAll); return false\">' + offers[offer].floors[floor] + '</a>'
              }
            }
          }
          let floors = document.getElementById('floorButtons');
          floors.innerHTML = floorsBtnHtml;
          if (filters.floor !== '') {
            let activeFloor = document.querySelector('#floorButtons [data-filter=\"' + filters.floor + '\"]')
            if (activeFloor) {
              activeFloor.classList.add(\"active\")
            } else {
              floors.firstElementChild.classList.add(\"active\")
            }
          }
        }

        function getSquare(offers, filters) {
          let squareBtnHtml = \"\"
          let squareNumberArray = []
          for (var offer in offers) {
            if (!squareNumberArray.includes(offers[offer].square)) {
              squareNumberArray.push(offers[offer].square)
              squareBtnHtml = squareBtnHtml + '<a class=\"square square-buttons__item\" data-filter=\"' + offers[offer].square + '\" href=\"#\" onclick=\"frontend.filterClick(\\'#squareButtons\\', this.getAttribute(\\'data-filter\\')); frontend.filterCreiate(offersAll); return false\">' + offers[offer].square + ' м<sup>2</sup></a>'
            }
          }
          let square = document.getElementById('squareButtons')
          square.innerHTML = squareBtnHtml

          if (filters.square == '') {
            let activeSquare = document.querySelector('#squareButtons .square-buttons__item:first-child')
            activeSquare.classList.add(\"active\");
          } else {
            let activeSquare = document.querySelector('#squareButtons [data-filter=\"' + filters.square + '\"]');
            activeSquare.classList.add(\"active\");
          }
        }

        function filterOffers(offersAll) {

          let offers = []
          for (let key in offersAll) {
            offers[key] = offersAll[key];
          }

          let filters = {
            square: document.querySelector('#squareButtons a.active') != null ? document.querySelector('#squareButtons a.active').getAttribute('data-filter') : '',
            floor: document.querySelector('#floorButtons a.active') != null ? document.querySelector('#floorButtons a.active').getAttribute('data-filter') : '',
          }

          getSquare(offers, filters)

          if (filters.square !== '') {
            for (var offer in offers) {
              if (offers[offer].square != filters.square) {
                delete offers[offer]
              }
            }
          }
          
          getFloors(offers, filters)

          if (filters.floor !== '') {
            for (var offer in offers) {
              if (!offers[offer].floors.includes(filters.floor)) {
                delete offers[offer]
              }
            }
          }

          renderOffers(offers)
          sortButtons('#floorButtons a')
          sortButtons('#squareButtons a')

        }

        function sortButtons(selector) {
          var nodeList = document.querySelectorAll(selector);
          var itemsArray = [];
          var parent = nodeList[0].parentNode;
          for (var i = 0; i < nodeList.length; i++) {
            itemsArray.push(parent.removeChild(nodeList[i]));
          }
          itemsArray.sort(function (nodeA, nodeB) {
            var textA = nodeA.getAttribute('data-filter');
            var textB = nodeB.getAttribute('data-filter');
            var numberA = parseInt(textA);
            var numberB = parseInt(textB);
            if (numberA < numberB) return -1;
            if (numberA > numberB) return 1;
            return 0;
          })
                  .forEach(function (node) {
                    parent.appendChild(node)
                  });
        }

        function renderOffers(offers) {
          const priceNode = document.querySelector('.location_price');
          const floorPlanNode = document.querySelector('.floor-plan__img');
          const locationPlanNode = document.querySelector('.locaton-plan__img');
          const buttonNode = document.querySelector('.download-link__location');
          const locations = offers.filter(el => {return el});
          const locationData = locations[0];

          priceNode.textContent = locationData.price + ' тг.';
          floorPlanNode.src = 'https://cms.abpx.kz' + locationData.floor_plan.path;
          locationPlanNode.src = 'https://cms.abpx.kz' + locationData.plan.path;
          buttonNode.href = 'https://cms.abpx.kz' + locationData.plan.path;
        }

        function startNewSwiper(offersAll) {
          let flatsCarousel = \$('.swiper-flats');
          
          flatsCarousel.owlCarousel();
        }

        function activateButton(parent, dataFilter) {
          let then = document.querySelector(parent + ' .active')
          let now = document.querySelector(parent + ' [data-filter=\"' + dataFilter + '\"]')

          if (then != null) {
            then.classList.remove('active')
          }
          if (now != null) {
            now.classList.add('active')
          }

          if (parent == \"#squareButtons\") {
            let floorActive = document.querySelector('#floorButtons .active')
            if (floorActive != null) {
              floorActive.classList.remove('active')
            }
          }

        }

        return {
          filterOffers: filterOffers,
          activateButton: activateButton
        }

      })()

      function correctStikyHeader() {
        const header = document.querySelector('.main-header');

        if (window.pageYOffset > 300) 
          header.classList.add('main-header--sticky');
      }

      function headerMenuLinks () {
        const menuItems = document.querySelectorAll('.navigate__link');

        menuItems.forEach(item => {
            item.addEventListener('click', (event) => {
                const el = document.querySelector(item.getAttribute('href'));
                const headerHeight = document.querySelector('header.main-header').offsetHeight;

                window.scrollTo({
                    top: el.offsetTop - headerHeight,
                    behavior: \"smooth\"
                });

                event.preventDefault();
            });
        });
      }

      function activeMenuItem(scroll) {
        const menuItems = document.querySelectorAll('.navigate__link:not(.lang-switcher__item)');
        const headerHeight = document.querySelector('header').offsetHeight;
        const checkActivation = (scroll, elTop, elBottom) => { 
            if (scroll >= elTop && scroll <= elBottom) {
                return true;
            }

            return false;
        }
        const selectElement = (element) => {
            const oldSelect = document.querySelector('.navigate__link--active');

            if (oldSelect) oldSelect.classList.remove('navigate__link--active');
            element.classList.add('navigate__link--active');
        }

        menuItems.forEach(item => {
            const el = document.querySelector(item.getAttribute('href'));

            if (el) {
              const isSelected = checkActivation(
                                      scroll, 
                                      el.offsetTop - headerHeight, 
                                      (el.offsetTop + el.offsetHeight) - headerHeight
                                  );

              if (isSelected) {
                  selectElement(item);
              }
            }
        });
      }
      
      function modal() {
        const buttons = document.querySelectorAll('[data-modal]');

        buttons.forEach((btn) => {
          btn.addEventListener('click', () => {
            const modal = document.querySelector(btn.getAttribute('data-modal'));

            modal.classList.toggle('modal--hidden');

            return false;
          });
        });
      }

      function toggleModal(btn) {
        const modal = document.querySelector(btn.getAttribute('data-modal'));

        modal.classList.toggle('modal--hidden');
        
        return false;
      }

      function renderAppertamentApp(data) {
        const state = {
          title: data.title,
          gallery: data.plan.map(item => { 
            return 'https://cms.abpx.kz' + item.path; 
          }),
          rooms: data.rooms,
          square: data.square,
          modalWrapper: document.createElement('div'),
          openModal: () => {
            document.body.appendChild(state.modalWrapper);
            inputGroupFocus();
            phoneValidator();

            setTimeout(() => {
              state.modalWrapper.style.height = window.innerHeight + 'px';
            }, 50);
          },
          closeModal: () => {
            state.modalWrapper.style.height = 0 + 'px';

            setTimeout(() => {
              state.modalWrapper.remove();
            }, 600)
          }
        };


        function render() {
          const container = document.createElement('div');
          const flex = document.createElement('div');
          const flex__left = document.createElement('div');
          const flex__right = document.createElement('div');
          const renderGallery = (imageLink = state.gallery[0]) => {
            const wrapper = document.createElement('div');
            const image = document.createElement('img');

            image.classList = 'appartament__image';
            image.src = imageLink;

            wrapper.classList = 'appartament__image-block';
            wrapper.appendChild(image);

            return wrapper;
          };
          const renderForm = () => {
            const formBlock = document.createElement('div');
            
            formBlock.classList = 'appartament__form';
            formBlock.innerHTML = `
              <h3 class=\"appartament__form-title\">Оставить заявку</h3>
              <form class=\"callback-h__form appartament__form--element\" action=\"#\">
                <div class=\"input-group callback-h__group\">
                    <label class=\"callback-h__label\" for=\"appatamentFormName\">Имя</label>
                    <input type=\"text\" class=\"input-group__input\" id=\"appatamentFormName\" name=\"name\" fieldname=\"Имя\">
                </div>

                <div class=\"input-group callback-h__group\">
                    <label class=\"callback-h__label\" for=\"appatamentFormPhone\">Телефон</label>
                    <input type=\"text\" class=\"input-group__input\" id=\"appatamentFormPhone\" name=\"phone\" fieldname=\"Телефон\" required=\"required\">
                </div>

                <div class=\"input-group input-group--button callback-h__group\">
                    <button class=\"btn btn--black callback-h__btn\" onclick=\"frontend.form(this); return false\">
                      Позвоните мне
                    </button>
                </div>
              </form>
            `;

            return formBlock;
          };      
          const selectFloorButtons = () => {
            const dl = document.createElement('dl');
            const dd = document.createElement('dd');
            const dt = document.createElement('dt');

            dd.textContent = 'Этаж: ';

            state.gallery.forEach((item, index) => {
              const btn = document.createElement('button');
              const activeClass = index === 0 ? 'appartament__floor-btn--active' : '';

              btn.classList = 'btn appartament__floor-btn ' + activeClass;
              btn.textContent = index;

              btn.addEventListener('click', function () {
                const btns = document.querySelectorAll('.appartament__floor-btn');

                flex__left.innerHTML = '';
                flex__left.appendChild(renderGallery(item));
                
                btns.forEach(item => { item.classList.remove('appartament__floor-btn--active') });
                btn.classList.add('appartament__floor-btn--active')
              });

              dt.appendChild(btn);
            });

            dl.append(dd, dt);

            return dl;
          }
          const renderInformation = () => {
            const information = document.createElement('div');
            const paramas = document.createElement('div');

            paramas.classList = 'appartament__paramas';
            paramas.innerHTML = `
              <dl>
                <dd>Общая площадь:</dd>
                <dt>\${state.square}</dt>
              </dl>
              <dl>
                <dd>Количество комнат</dd>
                <dt>\${state.rooms}</dt>
              </dl>
            `;
            paramas.appendChild(selectFloorButtons());

            information.classList = 'apparatament__info';
            information.innerHTML = `
              <div class=\"section-title\">
                  <h2 class=\"section-title__h2\">
                      <strong>\${state.title}</strong>
                  </h2>
              </div>
            `;
            information.appendChild(paramas);
            information.appendChild(renderForm());

            return information;
          };
          const renderCloseButton = () => {
            const btn = document.createElement('button');

            btn.classList = 'appartament__close-btn';
            btn.innerHTML = `
              <img src=\"assets/img/icons/close-btn.svg\">
            `;
            btn.addEventListener('click', () => {
              state.closeModal();
            });

            return btn;
          }

          flex__left.classList = 'flex__6 appartament__left';
          flex__left.appendChild(renderGallery());

          flex__right.classList = 'flex__6 appartament__right';
          flex__right.appendChild(renderInformation());

          flex.classList = 'flex appartament__flex';
          flex.appendChild(flex__left);
          flex.appendChild(flex__right);

          container.classList = 'container';
          container.appendChild(flex);

          state.modalWrapper.classList = 'appartaments__modal appartament';
          state.modalWrapper.appendChild(container);
          state.modalWrapper.appendChild(renderCloseButton());
        }

        render();

        state.openModal();
      }

      function interectiveMap() {
        const state = {
          polygons: document.querySelectorAll('.interective-map__polygon'),
          idAttribute: 'id',
          apiUrl: new URL('filter', document.location.href),
          requestData: function () {
            return fetch(state.apiUrl, {
              method: 'POST', 
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                id: this.getAttribute('data-' + state.idAttribute)
              })
            })
            .then(res => res.json())
          }
        }

        state.polygons.forEach(item => {
          item.addEventListener('click', function () {
            state.requestData.apply(this)
              .then(res => {
                renderAppertamentApp(res.entries[0]);
              })
          })
        });
      }

      function openModal() {
        \$('#callbackModal').modal('show');
      }

      function changeImgSize(){
            var img = this.content.find('img');
            img.css('max-height', '100%');
            img.css('width', 'auto');
            img.css('max-width', 'auto');
        }

      function openPopup(link) {
        \$.magnificPopup.open({
          items: {
            src: link.href
          }, 
          callbacks: {
              resize: changeImgSize,
              change:changeImgSize
          },
          type: 'image'
        });
      }

      function frontendReady() {
        authorMarker();
        // advantagesCarousel();
        // comfortCarousel();
        // buildingStepsCarousel();
        // galleryCarousel();
        // mainSliderCarousel();
        // closePreloader();
        // modal();
        // inputGroupFocus();
        phoneValidator();
        // headerMenuLinks();
        // correctStikyHeader();
        // sideBarToggleBtnEvent();
        // interectiveMap();
      }

      function frontendResize() {
        buildingStepsCarousel();
      }

      function frontendScroll() {
        activeMenuItem(window.pageYOffset);
        
        var scrollPosition = 0
        var header = document.querySelector('header');
        let slider = document.getElementById('home');

        if (window.pageYOffset < 700) {
          scroll1 = window.pageYOffset / 4;
          scroll2 = window.pageYOffset / 20;
        } else {
          if (!header.classList.contains('ymap')) {
            header.classList.add('ymap');
            ymaps.ready(frontend.yandex);
          }
        }

        if (window.pageYOffset > 50)\t{
          if (!header.classList.contains('main-header--hide')) {
            header.classList.add('main-header--hide');
          }
        } else {
          if (header.classList.contains('main-header--hide')) {
            header.classList.remove('main-header--hide');
          }
        }

        if (window.pageYOffset > 300)\t{
          if (!header.classList.contains('main-header--sticky')) {
            header.classList.add('main-header--sticky');
          }
        } else {
          if (header.classList.contains('main-header--sticky')) {
            header.classList.remove('main-header--sticky');
          }
        }
      }

      return {
        marker: authorMarker,
        steps: buildingStepsCarousel,
        advantages: advantagesCarousel,
        filterCreiate: newFilter.filterOffers,
        filterClick: newFilter.activateButton,
        lightBox: creiateLightbox,
        sidebar: sideBarToggle,
        map: creiateMap,
        yandex: yandexMap,
        form: formValidator,
        ready: frontendReady,
        resize: frontendResize,
        scroll: frontendScroll,
        modal: openModal,
        popup: openPopup,
      }

    })();

  \tdocument.addEventListener(\"DOMContentLoaded\", ()=>{ frontend.ready() });
  \t// window.addEventListener(\"resize\", ()=>{ frontend.resize() });
  \t// document.addEventListener(\"scroll\", ()=>{ frontend.scroll() });

  </script>

  <!-- jQuery -->
  <script src=\"";
        // line 1551
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/jquery-3.6.0.min.js\"></script>
  <script src=\"";
        // line 1552
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/jquery-migrate-3.0.0.min.js\"></script>
  <script src=\"";
        // line 1553
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/modernizr-2.6.2.min.js\"></script>
  <script src=\"";
        // line 1554
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/imagesloaded.pkgd.min.js\"></script>
  <script src=\"";
        // line 1555
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/jquery.isotope.v3.0.2.js\"></script>
  <script src=\"";
        // line 1556
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/pace.js\"></script>
  <script src=\"";
        // line 1557
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/popper.min.js\"></script>
  <script src=\"";
        // line 1558
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/bootstrap.min.js\"></script>
  <script src=\"";
        // line 1559
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/scrollIt.min.js\"></script>
  <script src=\"";
        // line 1560
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/jquery.waypoints.min.js\"></script>
  <script src=\"";
        // line 1561
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/owl.carousel.min.js\"></script>
  <script src=\"";
        // line 1562
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/jquery.stellar.min.js\"></script>
  <script src=\"";
        // line 1563
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/jquery.magnific-popup.js\"></script>
  <script src=\"";
        // line 1564
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/YouTubePopUp.js\"></script>
  <script src=\"";
        // line 1565
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/select2.js\"></script>
  <script src=\"";
        // line 1566
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/datepicker.js\"></script>
  <script src=\"";
        // line 1567
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/smooth-scroll.min.js\"></script>
  <script src=\"";
        // line 1568
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "assets/js/custom.js\"></script>

  ";
        // line 1571
        echo "
</html>
";
    }

    public function getTemplateName()
    {
        return "index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1733 => 1571,  1728 => 1568,  1724 => 1567,  1720 => 1566,  1716 => 1565,  1712 => 1564,  1708 => 1563,  1704 => 1562,  1700 => 1561,  1696 => 1560,  1692 => 1559,  1688 => 1558,  1684 => 1557,  1680 => 1556,  1676 => 1555,  1672 => 1554,  1668 => 1553,  1664 => 1552,  1660 => 1551,  172 => 66,  168 => 65,  164 => 64,  160 => 63,  156 => 62,  152 => 61,  148 => 60,  144 => 59,  134 => 52,  129 => 50,  124 => 48,  119 => 46,  114 => 44,  109 => 42,  104 => 40,  99 => 38,  94 => 36,  89 => 34,  84 => 32,  67 => 17,  62 => 13,  57 => 10,  53 => 9,  48 => 7,  44 => 6,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/index.twig");
    }
}
