<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/contacts.twig */
class __TwigTemplate_ad2f102512a1d5321ac0a8b8bd83715ebf2841d97f40ada4f2d4caa9b18e8dda extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Contacts -->
<section id=\"contacts\" class=\"contact section-padding\">
  <div class=\"container\">
      <div class=\"row align-items-center mb-90\">
          <div class=\"col-md-6 mb-60\">
              <div class=\"row\">
                  <div class=\"col-md-12\">
                      <div class=\"section-subtitle\"><span>Контакты</span></div>
                      <div class=\"section-title\">Обратная связь</div>
                  </div>
              </div>
              <div class=\"reservations mb-30\">
                  <div class=\"icon\"><span class=\"flaticon-call\"></span></div>
                  <div class=\"text\">
                      <p>Телефон</p> 
                      <a href=\"tel:+7 727 461 32 15\">+7 727 461 32 15</a>
                  </div>
              </div>
              <div class=\"reservations\">
                  <div class=\"icon\"><span class=\"flaticon-location-pin\"></span></div>
                  <div class=\"text\">
                      <p>Адрес</p> 
                      Алматы, ул. Кабанбай Батыра, 104, Центральный офис продаж              
                  </div>
              </div>
          </div>
          <div class=\"col-md-5 mb-30 offset-md-1\">
              <div class=\"booking-box\">
                      <div class=\"head-box\">
                          <h4>Оставьте заявку</h4>
                      </div>
                      <div class=\"booking-inner clearfix\">
                          <form 
                            action=\"#\" 
                            class=\"callback-h__form form1 clearfix\" 
                            onsubmit=\"frontend.form(this); return false\"
                          >
                              <div class=\"row\">
                                  <div class=\"col-md-12\">
                                      <div class=\"input1_wrapper\">
                                          <label id=\"contacts_form_name\">Ваше имя</label>
                                          <div class=\"input1_inner user\">
                                              <input 
                                                type=\"text\" 
                                                name=\"name\"
                                                class=\"form-control input input-group__input\" 
                                                placeholder=\"Имя\" 
                                                id=\"contacts_form_name\"
                                                fieldname=\"Имя\"
                                              >
                                          </div>
                                      </div>
                                  </div>
                                  <div class=\"col-md-12\">
                                      <div class=\"input1_wrapper\">
                                          <label id=\"contacts_form_phone\">Ваш телефон</label>
                                          <div class=\"input1_inner phone\">
                                              <input 
                                                type=\"text\" 
                                                name=\"phone\"
                                                class=\"form-control input input-group__input\" 
                                                placeholder=\"Телефон\" 
                                                id=\"contacts_form_phone\"
                                                fieldname=\"Телефон\"
                                              >
                                          </div>
                                      </div>
                                  </div>
                                  <div class=\"col-md-12\">
                                      <button 
                                        type=\"submit\" 
                                        class=\"btn-form1-submit mt-15\"
                                      >Отправить</button>
                                  </div>
                              </div>
                          </form>
                      </div>
                  </div>
          </div>
      </div>
      <!-- Map Section -->
      <div class=\"row\">
          <div class=\"col-md-12 map animate-box fadeInUp animated\" data-animate-effect=\"fadeInUp\">
              <iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16213.070620360735!2d76.94194043822336!3d43.24927786934216!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38836fa84993e1a5%3A0x9b17ee195bff7daa!2sExclusive%20Qurylys!5e0!3m2!1sru!2skz!4v1658702656809!5m2!1sru!2skz\" width=\"100%\" height=\"450px\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>
          </div>
      </div>
  </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/contacts.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/contacts.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/contacts.twig");
    }
}
