<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/modal.twig */
class __TwigTemplate_372592686b94cbe91b5d029423f01d5c92df8cef681732abd5f3fdea0439bc71 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Modal -->
<div 
    class=\"modal fade\" 
    id=\"callbackModal\" 
    tabindex=\"-1\" 
    aria-labelledby=\"callbackModal\" 
    aria-hidden=\"true\">
    <div class=\"modal-dialog modal-dialog-centered\">
        <div class=\"modal-content\">
            <div class=\"booking-box m-0 px-5\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                  <span aria-hidden=\"true\">&times;</span>
                </button>
                <div class=\"head-box\">
                    <h4>Оставьте заявку</h4>
                </div>
                <div class=\"booking-inner clearfix\">
                    <form 
                      action=\"#\" 
                      class=\"callback-h__form form1 clearfix\" 
                      onsubmit=\"frontend.form(this); return false\"
                    >
                        <div class=\"row\">
                            <div class=\"col-md-12\">
                                <div class=\"input1_wrapper\">
                                    <label id=\"modal_form_name\">Ваше имя</label>
                                    <div class=\"input1_inner user\">
                                        <input 
                                          type=\"text\" 
                                          name=\"name\"
                                          class=\"form-control input input-group__input\" 
                                          placeholder=\"Имя\" 
                                          id=\"modal_form_name\"
                                          fieldname=\"Имя\"
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class=\"col-md-12\">
                                <div class=\"input1_wrapper\">
                                    <label id=\"modal_form_phone\">Ваш телефон</label>
                                    <div class=\"input1_inner phone\">
                                        <input 
                                          type=\"text\" 
                                          name=\"phone\"
                                          class=\"form-control input input-group__input\" 
                                          placeholder=\"Телефон\" 
                                          id=\"modal_form_phone\"
                                          fieldname=\"Телефон\"
                                        >
                                    </div>
                                </div>
                            </div>
                            <div class=\"col-md-12\">
                                <button 
                                  type=\"submit\" 
                                  class=\"btn-form1-submit mt-15\"
                                >Отправить</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "widgets/modal.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/modal.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/modal.twig");
    }
}
