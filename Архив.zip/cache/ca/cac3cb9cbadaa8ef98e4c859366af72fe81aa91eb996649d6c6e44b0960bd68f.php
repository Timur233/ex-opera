<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/appartaments.twig */
class __TwigTemplate_a51e81722f2cda7ab4df16fc0e35efee98ca60d6e6f4f896f9bba915b6ae8812 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Filter -->
<section id=\"appartaments\" class=\"pricing section-padding bg-black\">
    <div class=\"container\">
        <div class=\"section-subtitle\"><span>Квартиры</span></div>
        <div class=\"section-title color-1\"><span>Подбор квартиры</span></div>
        <div class=\"row\">
            <div class=\"col-md-5\">
                <div class=\"locations__filter locations-filter\"></div>
                </div>
            <div class=\"col-md-7 locations__result locations-result\">
                <div class=\"locations-result__carousel owl-carousel\">
                </div>
            </div>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/appartaments.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/appartaments.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/appartaments.twig");
    }
}
