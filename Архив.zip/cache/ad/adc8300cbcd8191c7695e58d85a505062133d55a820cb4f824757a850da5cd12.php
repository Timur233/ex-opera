<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/_header.twig */
class __TwigTemplate_9c3e91833de1d2a4e662706ab64a384f271c2617e941c4641beb2b979fa1fb68 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!-- Navbar -->
<nav class=\"navbar navbar-expand-lg\">
   <div class=\"container\">
       <!-- Logo -->
       <div class=\"logo-wrapper navbar-brand valign\">
           <a href=\"#main\">
               <div class=\"logo\">
                   <img
                     src=\"https://cms.abpx.kz/storage/uploads/2022/07/21/62d8e024e6359white.svg\" 
                     class=\"logo-img\" 
                     alt=\"\"
                  >
               </div>
           </a>
       </div>
       <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\"> <span class=\"icon-bar\"><i class=\"ti-line-double\"></i></span> </button>
       <!-- Navbar links -->
       <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
           <ul class=\"navbar-nav m-auto\">
               <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"#about\">
                     О комплексе
                  </a>
               </li>
               <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"#advantages\">
                     Преимущества
                  </a>
               </li>
               <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"#appartaments\">
                     Квартиры
                  </a>
               </li>
               <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"#contacts\">
                     Контакты
                  </a>
               </li>
           </ul>
       </div>
       <!-- slider reservation -->
       <div class=\"header-reservation\">
           <a href=\"tel:+77274613215\">
               <div class=\"call\">
                  <span>
                     +7 727 461 32 15
                  </span> 
                  <br>
                  Call центр
               </div>
               <div class=\"icon d-flex justify-content-center align-items-center\">
                   <i class=\"flaticon-call\"></i>
               </div>
           </a>
       </div>
   </div>
</nav>";
    }

    public function getTemplateName()
    {
        return "widgets/_header.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/_header.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-opera/app/views/widgets/_header.twig");
    }
}
