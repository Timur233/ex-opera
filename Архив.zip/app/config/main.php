<?php

  define('BASE_URL',         $_ENV['BASE_URL'] ?? '');
  define('SING_TOKEN',       $_ENV['SING_TOKEN'] ?? '');
  define('SINGLETON',        $_ENV['SINGLETON'] ?? '');
  define('FORM_NAME',        $_ENV['FORM_NAME'] ?? '');
  define('FLATS_COLLECTION', $_ENV['FLATS_COLLECTION'] ?? '');
  define('PROJECT_ID',       "62189940313631c4c4000378");

?>
